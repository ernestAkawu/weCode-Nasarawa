# SuaCode - Smartphone-Based Coding Course  

[Course outline](https://drive.google.com/open?id=1odhEW4VrEUFmu_naQjywrJdXlLw5DucnLl1ctPliUXY)  
[0.0 Introduction](https://drive.google.com/open?id=1aCXiozFF8if6GMYiCiKmB6drrp1KF2XRn1DGOBtdqiY)  

## Lesson 1
[1.0 Basic Concepts in Processing](https://drive.google.com/open?id=1Ah2RlKPqW2Y6EIAthzgYRWgRNHaRgn8lYD1s6Cf1JEY)     
[Assignment 1 - Make Pong Interface](https://drive.google.com/open?id=1uNwWfBI9-JTlcmh4OZ8W9s7xPc9EuoupEIx6inne9iQ)

## Lesson 2
[2.0 Variables](https://drive.google.com/open?id=1unJWDGheh0vIjFXSvWHdjAl1T-C13PWvyDHL8CHKkAM)  
[Assignment 2 - Move Ball](https://drive.google.com/open?id=1Hxsg67pB8A7o4uTtmWK4219-tmAcAYscQbzL1cTohTw)  

## Lesson 3
[3.0 Conditionals](https://drive.google.com/open?id=1ZP7aoDq8TE9FNxepJw4ZSuDXOI4exUnPJH1qok_iv1s)  
[Assignment 3 - Bounce Ball](https://drive.google.com/open?id=1IFbPvciPSuUar1pM8bMxRZBpXrPCQYxEhAZX4AK-Ra8)  

## Lesson 4
[4.0 Functions](https://drive.google.com/open?id=1Oz3eQzm4tKTj0FtIMTWFoRTckcUBn4h7shqCvf3CX2A)  
[Assignment 4 - Move Paddles](https://drive.google.com/open?id=1gAJCekLfsulZZ5Jicy5wj1-Z2SVk3zt6y1ZgkFNVnRo)

## Lesson 5
[5.0 Classes and Objects](https://drive.google.com/open?id=1zUskf8ALY37QBPFdKxW13r7P1a4tDA-wbuPWhf5qX8w)  
[Assignment 5 - Add Extra Ball](https://drive.google.com/open?id=1HyvfK9PBYfdYXvVJPuuCc55RSEcamnvFYmf2HlmOzB0)  

## Lesson 6
[6.0 Loops & Arrays](https://drive.google.com/open?id=1bap7mffotjOWuVCfNIFqKK4Voxc283A88ppjH-y9HeQ)  
[Assignment 6 - Add More Balls](https://drive.google.com/open?id=1_NzBVM-dCDEcm7F9Zo-iT-cFzg9Oj7U6EQt8W42zLWE)  
